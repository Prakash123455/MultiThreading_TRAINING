import java.util.Scanner;

class Lab6Support extends Thread
{
	private String str;
	
public Lab6Support(String str) {
		super();
		this.str = str;
	}

@Override
public void run() {
	for (int i = 0;i<10 ;i++){
		System.out.print(str);
		try { Thread.sleep((int)(Math.random()*1000)); 	} catch (InterruptedException e) { 		e.printStackTrace(); 		}
	}

}	
}
public class Lab6_join {
	
public static void main(String[] args) {
	System.out.println("Press a number to continue");
	Scanner scanner = new Scanner(System.in);
	scanner.nextInt();
	
	Lab6Support t1 = new Lab6Support("A");
	t1.setName("AThread");
	Lab6Support t2 = new Lab6Support("B");
	t2.setName("BThread");
	Lab6Support t3 = new Lab6Support("C");
	t3.setName("CThread");
	t1.start();
	t2.start();
	t3.start();
	
	try {
		t1.join();
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	System.out.println("end of  main  after completing t1 ");
	
}
}

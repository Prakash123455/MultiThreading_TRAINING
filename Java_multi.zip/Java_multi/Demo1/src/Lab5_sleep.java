import java.util.Scanner;

class Lab5Support extends Thread
{
	static String finalloc;
	static boolean contflag=true;
	private String str;
	
public Lab5Support(String str) {
		super();
		this.str = str;
	}

@Override
public void run() {
	for (int i = 0;i<10 && contflag==true;i++){
		System.out.print(str);
		try { Thread.sleep((int)(Math.random()*100)); 	} catch (InterruptedException e) { 		e.printStackTrace(); 		}
	}
	if (contflag == true){
	System.out.println("\n"+ Thread.currentThread().getName() + " over and selected destination");
	finalloc = Thread.currentThread().getName();
	contflag = false;
	}
}	
}
public class Lab5_sleep {
	
public static void main(String[] args) {
	System.out.println("Press a number to continue");
	Scanner scanner = new Scanner(System.in);
	scanner.nextInt();
	
	Lab5Support t1 = new Lab5Support("A");
	t1.setName("AThread");
	Lab5Support t2 = new Lab5Support("B");
	t2.setName("BThread");
	Lab5Support t3 = new Lab5Support("C");
	t3.setName("CThread");
	t1.start();
	t2.start();
	t3.start();
	
	System.out.println("end of  main  ");
	for (int i = 0;i<10 ;i++){
		try { Thread.sleep(100); 	} catch (InterruptedException e) { 		e.printStackTrace(); 		}
		System.out.println("Status of t1 " + t1.isAlive());
		System.out.println("Status of t2 " + t2.isAlive());
		System.out.println("Status of t3 " + t3.isAlive());
	}
/*	while(true){
		if (t1.isAlive()== false){
			System.out.println("\n\nt1 is closed");
			break;
		}
		if (t2.isAlive()== false){
			System.out.println("\n\nt2 is closed");
			break;
		}
		if (t3.isAlive()== false){
			System.out.println("\n\nt3 is closed");
			break;
		}
	}
*/	
}
}

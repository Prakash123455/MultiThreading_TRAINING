import java.util.ArrayList;
import java.util.List;

class Lab1Support extends Thread
{
	private List<String> list ;
	
	public Lab1Support(List<String> list) 
	{
		this.list = list;
	}

	@Override
	public void run() 
	{
		for (int i = 1;i<=100;i++){
			synchronized(list)// we can not write synchronized(this)bcz it will lock the entire thread thatswhy we used synchronized(list) to lock list
			{
			/*try { Thread.sleep((int)(Math.random()*100)); 	} 
			catch (InterruptedException e) 
			{ 		
				e.printStackTrace(); 
			}
			*/
				//we can not sleep after taking lock thats why its bad practice to write inside synchronized block
				//but we can see the thread dump with this in visual vm
			list.add(Thread.currentThread().getName()+"-"+i);
			}
		}
	}
}
public class TwoThreadTryingToAccessList_Sync {
	public static void main(String[] args) 
	{
		List<String> list = new ArrayList<>();
		Lab1Support str = new Lab1Support(list);
		str.setName("str");
		str.start();
		Lab1Support mydata = new Lab1Support(list);
		mydata.setName("mydata");
		mydata.start();
		try 
		{
			str.join();
			mydata.join();
		} catch (InterruptedException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(list);
		System.out.println(list.size());
		
	}
}
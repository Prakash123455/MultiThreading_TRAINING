class Lab5Support extends Thread
	{
		private String str;
		
	public Lab5Support(String str) {
			super();
			this.str = str;
		}

	@Override
	public void run() {
		for (int i = 0;i<30;i++){
			System.out.print(str);
			try { Thread.sleep((int)(Math.random()*1000)); 	} catch (InterruptedException e) { 		e.printStackTrace(); 		}
		}
	}	
}
public class Time_Slice_Sleep {

	
	public static void main(String[] args) {
		
		Lab5Support lab1 = new Lab5Support("A");
		lab1.start();
		Lab5Support lab2 = new Lab5Support("B");
		lab2.start();
		Lab5Support lab3 = new Lab5Support("C");
		lab3.start();
		System.out.println("after starting the thread");

	}
}

import java.util.Scanner;

	class Lab4Support extends Thread
	{
		private String str;
		
	public Lab4Support(String str) {
			super();
			this.str = str;
		}

	@Override
	public void run() {
		for (int i = 0;i<1000;i++){
			System.out.print(str);
			if (i%100==0)
				System.out.println();
		}
	}	
}
public class Time_Slice {

	
	public static void main(String[] args) {
		
		/*Lab4Support lab1 = new Lab4Support("A");
		Lab4Support lab2 = new Lab4Support("B");
		Lab4Support lab3 = new Lab4Support("C");
		lab1.start();
		lab2.start();
		lab3.start();
		*/
		Lab4Support lab1 = new Lab4Support("A");
		lab1.start();
		Lab4Support lab2 = new Lab4Support("B");
		lab2.start();
		Lab4Support lab3 = new Lab4Support("C");
		lab3.start();
		System.out.println("after starting the thread");

	}
}

//stop current thread execution till t1 gets over

class Lab7Support extends Thread
{
	//static String finalloc;
	//static boolean contflag=true;
	private String str;

	public Lab7Support(String str) {
		super();
		this.str = str;
	}

	@Override
	public void run() {
		for (int i = 0;i<10 ;i++){
			System.out.print(str);
			try { Thread.sleep((int)(Math.random()*100)); 	} catch (InterruptedException e) { 		e.printStackTrace(); 		}
		}

	}	
}

public class Joins_StopThreadExecution 
{
	public static void main(String[] args) {
		Lab7Support lab1 = new Lab7Support("A");
		lab1.setName("AThread");

		Lab7Support lab2 = new Lab7Support("B");
		lab2.setName("BThread");

		Lab7Support lab3 = new Lab7Support("C");
		lab3.setName("CThread");
		lab1.start();
		lab2.start();
		lab3.start();
		System.out.println("--After starting the thread--");
		try {
			lab1.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("end of  main  after completing t1 ");

	}
}


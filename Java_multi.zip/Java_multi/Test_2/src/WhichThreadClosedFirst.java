//Write a main method to create and start 3 thread, need to display which thread is closed first

class Lab6Support extends Thread
{
	static String finalloc;
	static boolean contflag=true;
	private String str;
	
public Lab6Support(String str) {
		super();
		this.str = str;
	}

@Override
public void run() {
	for (int i = 0;i<10 && contflag==true;i++){
		System.out.print(str);
		try { Thread.sleep((int)(Math.random()*100)); 	} catch (InterruptedException e) { 		e.printStackTrace(); 		}
	}
	if (contflag == true)
	{
	System.out.println("\n"+ Thread.currentThread().getName() + " over and selected destination");
	finalloc = Thread.currentThread().getName();
	contflag = false;
	}
}	
}

public class WhichThreadClosedFirst 
{
public static void main(String[] args) {
	Lab6Support lab1 = new Lab6Support("A");
	lab1.setName("AThread");
	
	Lab6Support lab2 = new Lab6Support("B");
	lab2.setName("BThread");
	
	Lab6Support lab3 = new Lab6Support("C");
	lab3.setName("CThread");
	lab1.start();
	lab2.start();
	lab3.start();
	System.out.println("--After starting the thread--");
}
}
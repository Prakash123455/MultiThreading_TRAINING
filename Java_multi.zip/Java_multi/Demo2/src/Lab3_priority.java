import java.util.Scanner;

public class Lab3_priority {
	
	public static void main(String[] args) {
		System.out.println("Press a number to continue");
		Scanner scanner = new Scanner(System.in);
		scanner.nextInt();
		Runnable runnable = ()->{	for (int i = 0;i<10;i++){
			System.out.println("For - " + i +  " in thread " + Thread.currentThread().getName());
		}};
		
		Thread t1 = new Thread(runnable);
		t1.start();
		
		System.out.println("after starting the thread");

	}
}

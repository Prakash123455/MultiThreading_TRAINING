import java.util.Scanner;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class Lab3Support implements Callable<String> {
	@Override
	public String call() throws Exception {
		System.out.println("In  thread " + Thread.currentThread().getName());
		return "hi";
	}
}

public class Lab3 {

	public static void main(String[] args) {
		System.out.println("main - " + Thread.currentThread().getName());
		ExecutorService executorservice= Executors.newFixedThreadPool(5);
		executorservice.submit(new Lab3Support());
		executorservice.submit(new Lab3Support());
		executorservice.submit(new Lab3Support());
		executorservice.submit(new Lab3Support());
		executorservice.submit(new Lab3Support());
		
	}
}
